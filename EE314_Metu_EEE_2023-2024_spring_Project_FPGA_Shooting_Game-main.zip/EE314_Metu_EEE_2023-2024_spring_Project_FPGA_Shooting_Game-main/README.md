# EE314_Metu_EEE_2023-2024_spring_Project_FPGA_Shooting_Game
the project file may be corrupted but the main idea for this upload is to give you a general idea is to give an example on how a digital design project should more or less look like and give you a stable vga driver 
if the department is lazy enough which is not really posible they will use a token check to detect plagiarism so be advised
